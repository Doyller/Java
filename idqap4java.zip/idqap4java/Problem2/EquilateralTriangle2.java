package idqap4java.Problem2;

public class EquilateralTriangle2 extends Triangle2 {
    public EquilateralTriangle2(String name, double side) {
        super(name, side, side, side);
    }
}