package idqap4java.Problem2;


public interface Scalable {
    void scale(double scaleFactor);
}
