package idsprint1;

public class RentedVehicle {
    private double baseFee;

    public RentedVehicle(double baseFee) {
        this.baseFee = baseFee;
    }

    public double getBaseFee() {
        return baseFee;
    }

    public double getCost() {
        return baseFee;
    }
}
